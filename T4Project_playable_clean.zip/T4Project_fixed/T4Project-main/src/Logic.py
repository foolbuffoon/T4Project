from character import Character
from location import Location
from monsters import Monster
from spells import Spells
from weapons import Weapons
from consumables import Consumables

ART_LOGO = r"""
 __                               _                 _
/ _\\_      ____ _ _ __ ___  _ __ | | __ _ _ __   __| |
\\ \\ \\ / / _` | '_ ` _ \\| '_ \\| |/ _` | '_ \\ / _` |
_\\ \\ V  V / (_| | | | | | | |_) | | (_| | | | | (_| |
\\__/ \\_/\\_/ \\__,_|_| |_| |_| .__/|_|\\__,_|_| |_|_|
                           |_|
"""

def health_increase(character, consumable):
    if consumable.consume_type == 1:
        before = character.player_health
        character.heal(20)
        return character.player_health - before
    return 0

def status(player):
    print(f"\\nHealth: {player.player_health}/{player.max_health} | Mana: {player.mana}/{player.max_mana}")
    print("Inventory:", ", ".join(i.name for i in player.player_inventory) or "empty")

def combat(player, enemy):
    print(f"\\nA {enemy.name} attacks!")
    while player.alive and enemy.set_health > 0:
        status(player)
        print(f"{enemy.name} health: {enemy.set_health}")
        print("1. Attack with sword")
        print("2. Cast spell")
        print("3. Drink health potion")
        choice = input("> ").strip()

        if choice == "1":
            weapon = next((i for i in player.player_inventory if isinstance(i, Weapons)), None)
            damage = weapon.set_damage if weapon else 8
            enemy.set_health -= damage
            print(f"You strike the {enemy.name} for {damage} damage.")
        elif choice == "2":
            spell = next((i for i in player.player_inventory if isinstance(i, Spells)), None)
            if not spell:
                print("You don't know any spells.")
                continue
            if player.mana < spell.mana_cost:
                print("Not enough mana.")
                continue
            player.mana -= spell.mana_cost
            enemy.set_health -= spell.damage
            print(f"You cast {spell.name} for {spell.damage} damage.")
        elif choice == "3":
            potion = next((i for i in player.player_inventory if isinstance(i, Consumables)), None)
            if not potion:
                print("You have no health potion.")
                continue
            healed = health_increase(player, potion)
            player.player_inventory.remove(potion)
            print(f"You recover {healed} health.")
        else:
            print("Choose 1, 2, or 3.")
            continue

        if enemy.set_health > 0:
            enemy.attack(player)
            print(f"The {enemy.name} hits you for {enemy.set_damage} damage.")

    if player.alive:
        print(f"You defeated the {enemy.name}!")
        return True
    print("You collapse in the swamp...")
    return False

def play():
    player = Character()
    sword = Weapons()
    spell = Spells()
    potion = Consumables()
    player.player_inventory = [sword, spell, potion]

    locations = {
        "water": Location("Whispering Water", "Cold water cuts through the reeds.", True, False),
        "ruins": Location("Sunken Ruins", "Broken stone pillars rise from the mud.", True, True),
        "temple": Location("Slurok's Temple", "A dark temple hums with ancient magic.", True, False),
    }

    print("\nYou begin your journey...")
    print("You awake in a swamp, with a sword in your hand and no idea who you are.")
    print("\nTwo paths disappear into the fog.")
    while player.alive and not player.victory:
        print("\nWhat will you do?")
        print("1. Follow the running water")
        print("2. Explore the sunken ruins")
        print("3. Check your status")
        choice = input("> ").strip()

        if choice == "1":
            loc = locations["water"]
            print(f"\n{loc.name}: {loc.flavor}")
            if not combat(player, Monster("Bog Crawler", 28, 7)):
                break
            print("Beyond the water you discover a stone temple.")
            if combat(player, Monster("Swamp Guardian", 38, 9)):
                print("\nYou reach the entrance to Slurok's Temple.")
                if combat(player, Monster("Slurok", 55, 11)):
                    player.victory = True
        elif choice == "2":
            loc = locations["ruins"]
            print(f"\n{loc.name}: {loc.flavor}")
            if combat(player, Monster("Mire Wraith", 34, 8)):
                print("Inside the ruins you find another health potion.")
                player.add_item(Consumables())
        elif choice == "3":
            status(player)
        else:
            print("Choose 1, 2, or 3.")

    print("\n" + ART_LOGO)
    if player.victory:
        print("VICTORY! You defeated Slurok and escaped the Swampland.")
        print("The fog begins to clear, revealing a path leading out of the swamp.")
        print("But as you walk away, you hear something moving deep beneath the water...")
    else:
        print("GAME OVER. The Swampland claims another traveler.")

def main():
    while True:
        print(ART_LOGO)
        print("Welcome to Swampland, a text-based adventure game made by")
        print("Lilly Pernichele, Zack Poulson, Liam Scott, and Nikolas Kath.")
        input("\nPress Enter to begin...")
        play()
        again = input("\nPlay again? Y/N? ").strip().lower()
        if again != "y":
            print("Thanks for playing Swampland!")
            break

if __name__ == "__main__":
    main()
