class Character:
    def __init__(self):
        self.player_health = 100
        self.max_health = 100
        self.PLAYER_INVENTORY_SPACE = 10
        self.player_inventory = []
        self.victory = False
        self.player_money = 10
        self.alive = True
        self.mana = 20
        self.max_mana = 20

    def heal(self, amount):
        self.player_health = min(self.max_health, self.player_health + amount)

    def add_item(self, item):
        if len(self.player_inventory) < self.PLAYER_INVENTORY_SPACE:
            self.player_inventory.append(item)
            return True
        return False
