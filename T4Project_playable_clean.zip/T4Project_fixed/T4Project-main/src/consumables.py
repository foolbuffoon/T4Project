class Consumables:
    def __init__(self, name="Health Potion", consume_type=1):
        self.name = name
        self.consume_type = consume_type

    def set_type(self, x):
        self.consume_type = x

    def get_type(self):
        return self.consume_type
