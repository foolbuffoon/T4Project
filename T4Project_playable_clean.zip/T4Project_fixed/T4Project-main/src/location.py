class Location:
    def __init__(self, name, flavor="", has_monsters=False, has_items=False, exits=None):
        self.name = name
        self.flavor = flavor
        self.has_monsters = has_monsters
        self.has_items = has_items
        self.exits = exits or {}

    def travel(self, destination):
        return self.exits.get(destination)
