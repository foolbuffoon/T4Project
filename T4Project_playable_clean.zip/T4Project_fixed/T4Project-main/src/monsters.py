class Monster:
    def __init__(self, name="Swamp Beast", health=30, damage=8):
        self.name = name
        self.set_health = health
        self.set_damage = damage
        self.set_attack_interval = 1

    def attack(self, character):
        character.player_health = max(0, character.player_health - self.set_damage)
        if character.player_health == 0:
            character.alive = False
