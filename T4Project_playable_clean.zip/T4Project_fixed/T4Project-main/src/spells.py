class Spells:
    def __init__(self, name="Ember", damage=16, mana_cost=5):
        self.name = name
        self.spell_type = 1
        self.damage = damage
        self.mana_cost = mana_cost

    def typeSet(self):
        self.spell_type = 1
        return self.spell_type
