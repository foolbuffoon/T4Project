class Weapons:
    def __init__(self, name="Rusty Sword", damage=12, durability=20, damage_type="physical"):
        self.name = name
        self.set_damage = damage
        self.set_durability = durability
        self.damage_type = damage_type
